This folder contains the superpolys of katan family ciphers.
The folder KATAN32 contains the superpolys of KATAN32.
The folder KATAN48 contains the superpolys of KATAN48.
The folder KATAN64 contains the superpolys of KATAN64.
Let's illustrate the meaning of each file name. For example, 'log_katan95r_in24_13thbit' includes
superpoly results when we set the initial division property and the output division property
as in_24 and out_13 respectively. Other files' names have similar meanings.
We can get superpolys 'p' by summing monomials whose number of times are the odd numbers in each file. 


